
#!/usr/bin/bash

echo STARTING ----------
kubectl apply -f ~/mycode/yaml/ctce-drill-service-accounts.yaml
echo END OF SETUP ----------
